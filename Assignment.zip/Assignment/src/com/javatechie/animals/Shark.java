package com.javatechie.animals;

/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> Shark is a class which extends features from Fishes </h1>
 *
 */

@SuppressWarnings("serial")
public class Shark extends Fishes
{	
	private String size ="Large";
	private String colour ="grey";
	private String feature ="Eat other Fishes"; 
	
	
		public Shark() {
			 super.size =this.size;
			super.colour=this.colour;
			 super.features=this.feature;
	}

public void swim() {
		
		System.out.println(" I am Shark  can swim ");
		
	}
	
	
	
	
}
