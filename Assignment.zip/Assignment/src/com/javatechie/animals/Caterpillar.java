package com.javatechie.animals;

/**
 * 
 * @author Kiran Kumar
 * <h1>Caterpillar class is an  Implementation class  of  Animals Interface
 *</h1>
 */
public class Caterpillar implements Animals{
	/**
	 * walk() is the  only feature for Caterpillar  
	 */
	 public void walk() {
		
		  System.out.println("Caterpillar Crawls");
		}

}
