package com.javatechie.animals;

import java.io.Serializable;

/**
 * 
 * @author Kiran Kumar
 * <h1> Fishes is a seperate class having his own identities and features </h1> 
 *
 */
@SuppressWarnings("serial")
public class Fishes implements Serializable{

	/**
	 * size is an attribute for Fishes to distinguish different kinds of fishes based on Size
	 */
	public String size;
	/**
	 * colour is also an attribute for Fishes to distinguish different kinds of fishes based on colour
	 */
	public String colour;
	/**
	 * features is an attribute for Fishes to distinguish 
	 * different kinds of fishes based on Behaviour of Fishes
	 */
	public String features;
	
	
	
	public Fishes() {
	
	}



	public Fishes(String size, String colour, String features) {
	
		this.size = size;
		this.colour = colour;
		this.features = features;
	}



	public String getSize() {
		return size;
	}



	public void setSize(String size) {
		this.size = size;
	}



	public String getColour() {
		return colour;
	}



	public void setColour(String colour) {
		this.colour = colour;
	}



	public String getFeatures() {
		return features;
	}



	public void setFeatures(String features) {
		features = features;
	}


/**
 * swim() is an implemented method and default behavior of Fishes 
 */
	public void swim() {
		
		System.out.println(" I am Fish can swing ");
		
	}



	@Override
	public String toString() {
		return "Fishes [size=" + size + ", colour=" + colour + ", Features=" + features + "]";
	}
	
	
	
}
