package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> Duck is an Implementation class from Birds Interface and 
 * Inherits all features of Birds</h1>
 *
 */
public class Duck implements Birds{
/**
 * sing() is a Implemented method of Duck class and 
 * tells that Duck sings like "Quack quack"
 */
	@Override
	public void sing() {
		
		System.out.println("Quack quack");
		
	}
	
	

}
