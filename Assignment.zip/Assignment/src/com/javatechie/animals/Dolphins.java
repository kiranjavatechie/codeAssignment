package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> Dolphins is an Implementation class from Animals Interface and 
 * Inherits all features of Animals</h1>
 *
 */
public class Dolphins implements Animals{
	
	public void swim() {
		System.out.println(" I am Dolphin can swim  ");
	}


}
