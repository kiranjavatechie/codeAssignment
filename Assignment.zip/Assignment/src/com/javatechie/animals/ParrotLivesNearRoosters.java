package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> ParrotLivesNearRoosters is an Implementation class from Birds Interface and 
 * Inherits all features of Birds</h1>
 *
 */
public class ParrotLivesNearRoosters implements Birds{
	/**
	 * sing() is a Implemented method of ParrotLivesNearRoosters class and 
	 * tells that Parrot lives near Roosters sings like "cock-a doodle-doo"
	 */
	@Override
	public void sing() {
		System.out.println("cock-a doodle-doo");
	}
	

}
