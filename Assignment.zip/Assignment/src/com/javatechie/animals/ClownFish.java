package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> ClownFish is a class which extends features from Fishes</h1>
 *
 */
@SuppressWarnings("serial")
public class ClownFish extends Fishes{

	private String size ="Small";
	private String colour ="Orange";
	private String feature ="Make Jokes";
	public ClownFish() {
		
		super.size =this.size;
		super.colour=this.colour;
		 super.features=this.feature;
	} 
	
public void swim() {
		
		System.out.println(" I am Clown fish  can swim ");
		
	}
	
	
}
