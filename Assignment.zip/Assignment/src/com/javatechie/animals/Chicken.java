package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> Chicken is an Implementation class from Birds Interface and 
 * Inherits all features of Birds</h1>
 *
 */
public class Chicken implements Birds{
	/**
	 * sing() is a Implemented method of Chicken class and 
	 * tells that Chicken sings like "cluck,cluck"
	 */
	@Override
	public void sing() {
		System.out.println("cluck,cluck");
	}

}
