package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> ParrotLivesWithCats is an Implementation class from Birds Interface and 
 * Inherits all features of Birds</h1>
 *
 */
public class ParrotLivesWithCats implements Birds{
	/**
	 * sing() is a Implemented method of ParrotLivesWithCats class and 
	 * tells that Parrot lives with Cats sings like "Meow"
	 */
	@Override
	public void sing() {
		System.out.println("Meow");
	}
	

}
