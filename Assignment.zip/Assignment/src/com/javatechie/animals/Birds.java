package com.javatechie.animals;

/**
 * 
 * @author Kiran Kumar
 * <h1>Birds interface is an abstract Implementation of its Implemented Classes 
 * and also its extends the features from Animal Interface
 *</h1>
 */
public interface Birds  extends Animals {
	/**
	 * fly() is the default feature for Birds and it uses most of them 
	 */
	default public void fly() {
		
		System.out.println(" I can fly  ");
	}
	/**
	 * sing() is also one of the important feature most of the Birds have
	 */
	public void sing();

}
