package com.javatechie.animals;

/**
 * 
 * @author Kiran Kumar
 *
 *This Animal Interface is used as abstract implementation of all Implemented Classes
 */
public interface Animals {
	
	/**
	 * walk() method is a kind of behaviour explained for animals .
	 * Most of the animals have this feature
	 */
	default public void walk() {
		
	  System.out.println("Animals can walk");
	}
	/**
	 * swim() method is a kind of behaviour explained for animals.
	 * few of them have this feature 
	 */
   default public void swim() {
		
		System.out.println(" I Can swim");
	}
}
