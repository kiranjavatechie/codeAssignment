package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> ParrotLivesWithDogs is an Implementation class from Birds Interface and 
 * Inherits all features of Birds</h1>
 *
 */
public class ParrotLivesWithDogs implements Birds{
	/**
	 * sing() is a Implemented method of ParrotLivesWithDogs class and 
	 * tells that Parrot lives with Dogs sings like "Woof,Woof"
	 */
	@Override
	public void sing() {
		System.out.println("Woof,Woof");
	}
	

}
