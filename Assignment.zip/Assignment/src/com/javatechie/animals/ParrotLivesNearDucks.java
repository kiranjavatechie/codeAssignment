package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> ParrotLivesNearDucks is an Implementation class from Birds Interface and 
 * Inherits all features of Birds</h1>
 *
 */
public class ParrotLivesNearDucks implements Birds{
	/**
	 * sing() is a Implemented method of ParrotLivesNearDucks class and 
	 * tells that Parrot lives near Ducks sings like "Quack,quak"
	 */
	@Override
	public void sing() {
		System.out.println("Quack,quak");
	}
	

}
