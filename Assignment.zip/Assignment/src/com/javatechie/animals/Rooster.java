package com.javatechie.animals;
/**
 * 
 * @author Kiran Kumar
 * 
 * <h1> Rooster is an Implementation class from Birds Interface and 
 * Inherits all features of Birds</h1>
 *
 */
public class Rooster implements Birds{
	/**
	 * sing() is a Implemented method of Rooster class and 
	 * tells that Rooster sings in English like "Cock-a-doodle-doo"
	 */
	@Override
	public void sing() {
		
		System.out.println("Cock-a-doodle-doo");
		
	}
	/**
	 * singOtherLang() is a own method of Duck class and 
	 * tells that Rooster will sing in Other languages
	 * @param lang 
	 *  which language  u need to sing 
	 * @return String
	 *  returned voice of speech of that language 
	 */
	public String singOtherLang(String lang)
	{
		
		if(lang !=null)
		{
			switch(lang)
			{
			case "Danish": 
				return "Rooster sang in Danish:---->kykyliky";
			case "Dutch":
				return "Rooster sang in Dutch:--->kukeleku";
			case "Finnish":
				return "Rooster sang in Finnish:--->kukko kiekuu";
			case "French":
				return "Rooster sang in French:--->cocorico";
			case "German":
				return "Rooster sang in German:--->kikeriki";
			case "Greek":
				return "Rooster sang in Greek:--->kikiriki";
			case "Hebrew":
				return "Rooster sang in Hebrew:--->coo-koo-ri-koo";
			case "Hungarian":
				return "Rooster sang in Hungarian:--->kukuriku";
			case "Italian":
				return "Rooster sang in Italian:--->chicchirichi";
			case "Japanese":
				return "Rooster sang in Japanese:--->ko-ke-kok-ko-o";
			case "Portuguese":
				return "Rooster sang in Portuguese:--->cucurucu";
			case "Russian":
				return "Rooster sang in Russian:--->kukareku";
			case "Swedish":
				return "Rooster sang in Swedish:--->kuckeliku";
			case "Turkish":
				return "Rooster sang in Turkish:--->kuk-kurri-kuuu";
			case "Urdu":
				return "Rooster sang in Urdu:--->kuklooku";
			case "Telugu":
				return "Rooster sang in Native Telugu language:--->coo-koo-ra-koo";
			 
			
			}
		}
		return lang;
	}

}
