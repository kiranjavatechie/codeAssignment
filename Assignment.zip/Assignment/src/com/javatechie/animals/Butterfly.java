package com.javatechie.animals;

/**
 * 
 * @author Kiran Kumar
 * <h1>Butterfly class is an  Implementation class  of  Animals Interface
 *</h1>
 */
public class Butterfly implements Animals{
	/**
	 * fly() is the  only feature for Butterfly 
	 */
public void fly() {
		
		System.out.println("Butterfly  flies  ");
	}

}
