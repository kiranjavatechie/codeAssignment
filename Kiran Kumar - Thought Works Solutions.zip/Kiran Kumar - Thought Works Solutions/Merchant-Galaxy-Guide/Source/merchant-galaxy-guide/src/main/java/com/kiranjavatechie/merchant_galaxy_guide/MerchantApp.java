package com.kiranjavatechie.merchant_galaxy_guide;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import com.google.common.collect.ImmutableList;

import com.kiranjavatechie.merchant_galaxy_guide.GalaxyMerchantGuide;

/**
 * 
 * @author Kiran Kumar
 *
 */
public class MerchantApp 
{
    public static void main( String[] args )throws IOException, URISyntaxException 
    {
    	 System.out.println("Merchant Galaxy Conversion starts---->");
         final List<String> input = Files.readAllLines(Paths.get(ClassLoader.getSystemResource("inputFile").toURI()));
         new GalaxyMerchantGuide().startTrading(ImmutableList.copyOf(input));
    }
}
