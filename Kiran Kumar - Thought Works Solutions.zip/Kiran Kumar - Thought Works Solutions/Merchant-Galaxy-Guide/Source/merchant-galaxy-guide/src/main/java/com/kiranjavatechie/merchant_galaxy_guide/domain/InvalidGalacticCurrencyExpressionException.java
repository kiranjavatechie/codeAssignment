package com.kiranjavatechie.merchant_galaxy_guide.domain;
/**
 * 
 * @author Kiran Kumar
 *
 */
@SuppressWarnings("serial")
public class InvalidGalacticCurrencyExpressionException extends RuntimeException {

}
