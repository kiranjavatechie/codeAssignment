package com.kiranjavatechie.merchant_galaxy_guide.domain;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.google.common.collect.Lists;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * 
 * @author Kiran Kumar
 *
 */
@EqualsAndHashCode(of = "symbol")
@ToString(of = "symbol")
@AllArgsConstructor
public class RareTypeMetal {


    private final String symbol;

    @Getter
    private final BigDecimal perUnitValue;

    /**
     * @param assignmentTransaction
     * @param galacticCurrenciesInTransaction
     * @return
     */
    public static RareTypeMetal createFromAssignmentTransaction(String assignmentTransaction,
                                                            final GalacticCurrencyExpression galacticCurrenciesInTransaction) {
        final Integer galacticCurrencyExpressionValue = galacticCurrenciesInTransaction.getGalacticCurrencyExpressionValue();
        final String RareTypeMetalSymbol = extractRareTypeMetalSymbol(assignmentTransaction);
        final Integer creditValue = extractCreditValueFromAssignmentTransaction(assignmentTransaction);
        BigDecimal perUnitValue = BigDecimal.valueOf(creditValue).divide(BigDecimal.valueOf(galacticCurrencyExpressionValue));
        return new RareTypeMetal(RareTypeMetalSymbol, perUnitValue);
    }

    static String extractRareTypeMetalSymbol(String assignmentTransaction) {
        final String[] components = assignmentTransaction.split(" ");
        for (int i = 0; i < components.length; i++) {
            if(components[i].equals("is")){
                return components[i-1];
            }
        }
        throw new InvalidGalacticCurrencyTransactionException("No Rare metal symbol in transaction");
    }

    /**
     * @param assignmentTransaction
     * @return
     */
    static Integer extractCreditValueFromAssignmentTransaction(String assignmentTransaction) {
        final String[] components = assignmentTransaction.split(" ");
        for (int i = 0; i < components.length; i++) {
            if(components[i].equals("Credits")){
                return Integer.valueOf(components[i-1]);
            }
        }
        throw new InvalidGalacticCurrencyTransactionException("No credits found in transaction");
    }

    public static Optional<RareTypeMetal> selectBySymbol(final String RareTypeMetalSymbol,final Collection<RareTypeMetal> RareTypeMetals){
        return RareTypeMetals.stream().filter(RareTypeMetal -> RareTypeMetal.symbol.equals(RareTypeMetalSymbol)).findFirst();
    }

    /**
     * @param inputWithoutCurrencyAssignments
     * @param galacticCurrenciesMasterList
     * @return
     */
    public static List<RareTypeMetal> RareTypeMetalsInTransactionLogs(List<String> inputWithoutCurrencyAssignments,
                                                       List<GalacticCurrency> galacticCurrenciesMasterList) {
        final List<String> RareTypeMetalPerUnitValueAssignmentTransactions = SelectRareTypeMetalPerUnitValueAssignmentTransactions(inputWithoutCurrencyAssignments);
        final List<RareTypeMetal> RareTypeMetalsInTransactionLogs = Lists.newArrayList();
        for (String RareTypeMetalPerUnitValueAssignmentTransaction : RareTypeMetalPerUnitValueAssignmentTransactions) {
            final List<GalacticCurrency> galacticCurrenciesInTransaction = GalacticCurrency.
                    createFromTransactionComponents(Arrays.asList(RareTypeMetalPerUnitValueAssignmentTransaction.split(" "))
                            , galacticCurrenciesMasterList);
            GalacticCurrencyExpression galacticCurrencyExpression =
                    new GalacticCurrencyExpression(galacticCurrenciesInTransaction);
            final RareTypeMetal rareTypeMetal = RareTypeMetal.createFromAssignmentTransaction(RareTypeMetalPerUnitValueAssignmentTransaction, galacticCurrencyExpression);
            RareTypeMetalsInTransactionLogs.add(rareTypeMetal);
        }
        return RareTypeMetalsInTransactionLogs;
    }

    /**
     * @param sanitizedInput
     * @return
     */
    static List<String> SelectRareTypeMetalPerUnitValueAssignmentTransactions(List<String> sanitizedInput) {
        return sanitizedInput.stream().filter(transaction -> transaction.endsWith("Credits")).collect(Collectors.toList());
    }

}
