package com.kiranjavatechie.merchant_galaxy_guide.domain;

import java.util.Collections;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
/**
 * 
 * @author Kiran Kumar
 *
 */
@AllArgsConstructor
@EqualsAndHashCode(of = "symbol")
@ToString(of = "symbol")
public class RomanTypeSymbols {

	 @Getter(AccessLevel.PACKAGE)
	    private final Character symbol;
	    @Getter
	    private final Boolean isRepeatable;
	    @Getter
	    private final Boolean isSubtractable;
	    @Getter
	    private final List<RomanTypeSymbols> subtractableFrom;
	    @Getter
	    private final Integer value;

	    final static RomanTypeSymbols ZERO = ZeroSymbol();

	    public static RomanTypeSymbols StandaloneSymbol(Character symbol,Integer value){
	        return new RomanTypeSymbols(symbol,Boolean.FALSE,Boolean.FALSE, Collections.emptyList(),value);
	    }

	    public static RomanTypeSymbols RepeatableAndSubtractableSymbol(Character symbol,List<RomanTypeSymbols> subtractableFrom,Integer value){
	        return new RomanTypeSymbols(symbol,Boolean.TRUE,Boolean.TRUE, subtractableFrom,value);
	    }

	    static RomanTypeSymbols ZeroSymbol(){
	        return new RomanTypeSymbols('Z',Boolean.FALSE,Boolean.FALSE, Collections.emptyList(),0);
	    }
	    public boolean sameSymbol(Character symbol){
	        return this.symbol.equals(symbol);
	    }
}
