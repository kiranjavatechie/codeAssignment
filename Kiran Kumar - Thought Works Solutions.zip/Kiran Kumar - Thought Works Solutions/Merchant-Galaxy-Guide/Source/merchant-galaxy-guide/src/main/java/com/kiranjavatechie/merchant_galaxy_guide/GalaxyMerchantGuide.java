package com.kiranjavatechie.merchant_galaxy_guide;

import static com.kiranjavatechie.merchant_galaxy_guide.domain.RareTypeMetal.RareTypeMetalsInTransactionLogs;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.kiranjavatechie.merchant_galaxy_guide.domain.GalacticCurrency;
import com.kiranjavatechie.merchant_galaxy_guide.domain.RareTypeMetal;
import com.kiranjavatechie.merchant_galaxy_guide.domain.RomanTypeSymbols;

import lombok.Getter;

/**
 * 
 * @author Kiran Kumar
 *
 */
public class GalaxyMerchantGuide {

	 @Getter
	    private final List<RomanTypeSymbols> romanTypeSymbols;

	    public GalaxyMerchantGuide() {
	        RomanTypeSymbols RomanTypeSymbolsThousand = RomanTypeSymbols.StandaloneSymbol('M', 1000);
	        RomanTypeSymbols RomanTypeSymbolsFiveHundred = RomanTypeSymbols.StandaloneSymbol('D', 500);
	        RomanTypeSymbols RomanTypeSymbolsFifty = RomanTypeSymbols.StandaloneSymbol('L', 50);
	        RomanTypeSymbols RomanTypeSymbolsFive = RomanTypeSymbols.StandaloneSymbol('V', 5);
	        RomanTypeSymbols RomanTypeSymbolsHundred = RomanTypeSymbols.RepeatableAndSubtractableSymbol('C', Lists.newArrayList(RomanTypeSymbolsFiveHundred, RomanTypeSymbolsThousand), 100);
	        RomanTypeSymbols RomanTypeSymbolsTen = RomanTypeSymbols.RepeatableAndSubtractableSymbol('X', Lists.newArrayList(RomanTypeSymbolsFifty, RomanTypeSymbolsHundred), 10);
	        RomanTypeSymbols RomanTypeSymbolsOne = RomanTypeSymbols.RepeatableAndSubtractableSymbol('I', Lists.newArrayList(RomanTypeSymbolsFive, RomanTypeSymbolsTen), 1);
	        romanTypeSymbols = ImmutableList.of(RomanTypeSymbolsOne, RomanTypeSymbolsFive, RomanTypeSymbolsTen, RomanTypeSymbolsFifty,
	                RomanTypeSymbolsHundred, RomanTypeSymbolsFiveHundred, RomanTypeSymbolsThousand);

	    }


	    /**
	     * @param merchantTransactions
	     * @return
	     */
	    public List<String> startTrading(final List<String> merchantTransactions) {
	        final List<String> sanitizedInput = SantizeInput(merchantTransactions);
	        List<String> galacticCurrencyAssignments = SelectOnlyGalacticCurrencyAssignments(merchantTransactions, romanTypeSymbols);
	        final List<GalacticCurrency> galacticCurrencies = ImmutableList.copyOf(CreateGalacticCurrencies(galacticCurrencyAssignments, romanTypeSymbols));
	        final ArrayList<String> inputWithoutCurrencyAssignments = Lists.newArrayList(sanitizedInput);
	        inputWithoutCurrencyAssignments.removeAll(galacticCurrencyAssignments);
	        List<String> output = CalculateAndPrint(inputWithoutCurrencyAssignments, galacticCurrencies);
	        return output;
	    }

	    static List<String> SantizeInput(final List<String> inputs) {
	        return inputs.stream().map(input -> input.trim().replaceAll(" +", " ")
	        ).collect(Collectors.toList());
	    }

	    static List<String> SelectOnlyGalacticCurrencyAssignments(List<String> merchantTransactions, List<RomanTypeSymbols> RomanTypeSymbolss) {
	        return merchantTransactions.stream().filter(merchantTransaction -> {
	            if (merchantTransaction.split(" ").length == 3) {
	                final Character symbol = merchantTransaction.split(" ")[2].toCharArray()[0];
	                final Optional<RomanTypeSymbols> matchedRomanTypeSymbols = RomanTypeSymbolss.stream().filter(RomanTypeSymbols -> RomanTypeSymbols.sameSymbol(symbol)).findAny();
	                return matchedRomanTypeSymbols.isPresent();
	            }
	            return false;
	        }).collect(Collectors.toList());
	    }

	    static List<GalacticCurrency> CreateGalacticCurrencies(List<String> galacticCurrencyAssignments, List<RomanTypeSymbols> RomanTypeSymbolss) {
	        return galacticCurrencyAssignments.stream().map(galacticCurrency -> {
	            final String[] transaction = galacticCurrency.split(" ");
	            final String galacticCurrencySymbol = transaction[0];
	            final Character romanValueSymbol = transaction[2].toCharArray()[0];
	            final RomanTypeSymbols selectedRomanTypeSymbols = RomanTypeSymbolss.stream().filter(RomanTypeSymbols ->
	                    RomanTypeSymbols.sameSymbol(romanValueSymbol)).findAny().get();
	            return new GalacticCurrency(galacticCurrencySymbol, selectedRomanTypeSymbols);
	        }).collect(Collectors.toList());
	    }

	    private static List<String> CalculateAndPrint(List<String> inputWithoutCurrencyAssignments, final List<GalacticCurrency> galacticCurrenciesMasterList) {
	        final List<RareTypeMetal> rareMetals = RareTypeMetalsInTransactionLogs(inputWithoutCurrencyAssignments, galacticCurrenciesMasterList);
	        ConsoleOutputManager consoleOutputManager = new ConsoleOutputManager(galacticCurrenciesMasterList);
	        final List<String> galacticExpressionInTransactionLogs = PrintGalacticExpressionInTransactionLogs(inputWithoutCurrencyAssignments, consoleOutputManager);
	        final List<String> creditsTransactionsInTransactionLogs = PrintCreditsTransactionsInTransactionLogs(inputWithoutCurrencyAssignments, consoleOutputManager, rareMetals);
	        List<String> output = Lists.newArrayList(galacticExpressionInTransactionLogs);
	        output.addAll(creditsTransactionsInTransactionLogs);
	        return output;
	    }

	    private static List<String> PrintCreditsTransactionsInTransactionLogs(List<String> inputWithoutCurrencyAssignments,
	                                                                  ConsoleOutputManager consoleOutputManager, List<RareTypeMetal> rareMetals) {
	        return consoleOutputManager.printCreditsTransactionsInTransactionLogs(inputWithoutCurrencyAssignments ,rareMetals);
	    }

	    /**
	     * @param inputWithoutCurrencyAssignments
	     * @return
	     */
	    private static List<String> PrintGalacticExpressionInTransactionLogs(List<String> inputWithoutCurrencyAssignments, ConsoleOutputManager consoleOutputManager) {
	        return consoleOutputManager.printGalacticCurrencyExpressionInTransactionLogs(inputWithoutCurrencyAssignments);
	    }

}
