package com.kiranjavatechie.merchant_galaxy_guide.domain;
/**
 * 
 * @author Kiran Kumar
 *
 */
@SuppressWarnings("serial")
public class InvalidGalacticCurrencyTransactionException extends RuntimeException {

	public InvalidGalacticCurrencyTransactionException(String s) {
		super(s);
		
	}

	
}
