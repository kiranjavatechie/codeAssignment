package com.kiranjavatechie.merchant_galaxy_guide.domain;

import com.google.common.primitives.Ints;


import lombok.*;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 
 * @author Kiran Kumar
 *
 */
@ToString(of = "symbol")
@AllArgsConstructor
@EqualsAndHashCode(of = "symbol")
public class GalacticCurrency {


    @Getter
    final String symbol;
    @Getter(AccessLevel.PACKAGE)
    final private RomanTypeSymbols romanTypeSymbols;

    final static GalacticCurrency ZERO = new GalacticCurrency("ZERO",RomanTypeSymbols.ZERO);

    public static GalacticCurrency createFromTransactionComponent(String galacticCurrencySymbol, List<GalacticCurrency> galacticCurrenciesMasterList) {
        return galacticCurrenciesMasterList.stream().filter(galacticCurrency -> galacticCurrency.isSame(galacticCurrencySymbol)).findFirst().get();
    }

    public static List<GalacticCurrency> createFromTransactionComponents(List<String> transactionComponents, List<GalacticCurrency> galacticCurrenciesMasterList) {
        final Stream<String> galacticCurrencyComponents = transactionComponents.stream().
                filter(transactionComponent -> {
                    return galacticCurrenciesMasterList.stream().anyMatch(galacticCurrency -> galacticCurrency.isSame(transactionComponent));
                });
        final List<GalacticCurrency> galacticCurrenciesInTransaction = galacticCurrencyComponents.map(galacticCurrencySymbol ->
                createFromTransactionComponent(galacticCurrencySymbol, galacticCurrenciesMasterList)).collect(Collectors.toList());
        return galacticCurrenciesInTransaction;
    }

    public boolean isSame(String symbol) {
        return this.symbol.equals(symbol);
    }

    public Boolean isRepeatable() {
        return romanTypeSymbols.getIsRepeatable();
    }

    public Boolean isSubstractable() {
        return romanTypeSymbols.getIsSubtractable();
    }

    public Integer getDecimalValue() {
        return romanTypeSymbols.getValue();
    }

    public Boolean isValidSubtraction(GalacticCurrency galacticCurrency) {
        return this.isSubstractable() && this.romanTypeSymbols.getSubtractableFrom().contains(galacticCurrency.getRomanTypeSymbols());
    }


}
