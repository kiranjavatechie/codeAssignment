package com.kiranjavatechie.merchant_galaxy_guide.domain;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;

public class RareTypeMetalTest {

	List<GalacticCurrency> galacticCurrencies;

	@Before
	public void setup() {
		RomanTypeSymbols romanSymbolThousand = RomanTypeSymbols.StandaloneSymbol('M', 1000);
		RomanTypeSymbols romanSymbolFiveHundred = RomanTypeSymbols.StandaloneSymbol('D', 500);
		RomanTypeSymbols romanSymbolFifty = RomanTypeSymbols.StandaloneSymbol('L', 50);
		RomanTypeSymbols romanSymbolFive = RomanTypeSymbols.StandaloneSymbol('V', 5);
		RomanTypeSymbols romanSymbolHundred = RomanTypeSymbols.RepeatableAndSubtractableSymbol('C',
				Lists.newArrayList(romanSymbolFiveHundred, romanSymbolThousand), 100);
		RomanTypeSymbols romanSymbolTen = RomanTypeSymbols.RepeatableAndSubtractableSymbol('X',
				Lists.newArrayList(romanSymbolFifty, romanSymbolHundred), 10);
		RomanTypeSymbols romanSymbolOne = RomanTypeSymbols.RepeatableAndSubtractableSymbol('I',
				Lists.newArrayList(romanSymbolFive, romanSymbolTen), 1);
		galacticCurrencies = ImmutableList.of(new GalacticCurrency("glob", romanSymbolOne),
				new GalacticCurrency("prok", romanSymbolFive), new GalacticCurrency("pish", romanSymbolTen),
				new GalacticCurrency("tegj", romanSymbolFifty));

	}

	@Test
	public void givenRareTypeMetalAssignmentTransaction_itShouldExtractCreditValue() {
		final Integer expectedCreditValue = RareTypeMetal
				.extractCreditValueFromAssignmentTransaction("glob prok Gold is 57800 Credits");
		assertThat(expectedCreditValue).isEqualTo(57800);
	}

	@Test
	public void givenRareTypeMetalAssignmentTransaction_itShouldRareTypeMetalSymbol() {
		final String expectedRareTypeMetalSymbol = RareTypeMetal.extractRareTypeMetalSymbol("glob prok Gold is 57800 Credits");
		assertThat(expectedRareTypeMetalSymbol).isEqualTo("Gold");
	}

	@Test
	public void givenRareTypeMetalAssignmentTransaction_itShouldCalculateRareTypeMetalPerUnitValue() throws Exception {
		List<GalacticCurrency> galacticCurrenciesInTransaction = galacticCurrencies.subList(0, 2);
		GalacticCurrencyExpression galacticCurrencyExpression = new GalacticCurrencyExpression(
				galacticCurrenciesInTransaction);
		final RareTypeMetal goldRareTypeMetal = RareTypeMetal.createFromAssignmentTransaction("glob prok Gold is 57800 Credits",
				galacticCurrencyExpression);
		assertThat(goldRareTypeMetal.getPerUnitValue()).isEqualTo(BigDecimal.valueOf(14450));
		galacticCurrenciesInTransaction = Lists.newArrayList(galacticCurrencies.get(2), galacticCurrencies.get(2));
		galacticCurrencyExpression = new GalacticCurrencyExpression(galacticCurrenciesInTransaction);
		final RareTypeMetal ironRareTypeMetal = RareTypeMetal.createFromAssignmentTransaction("pish pish Iron is 3910 Credits",
				galacticCurrencyExpression);
		assertThat(ironRareTypeMetal.getPerUnitValue()).isEqualTo(BigDecimal.valueOf(195.5));
	}

	@Test
	public void givenAllTransactions_whenSelectingRareTypeMetalTransactions_itShouldReturnAllRareTypeMetalPerUnitTransactions() {
		List<String> allTransactions = Lists.newArrayList("glob is I", "glob glob Silver is 34 Credits",
				"prok Gold is 57800 Credits", "how many Credits is glob prok Iron ?");
		final List<String> rareMetalPerUnitValueAssignmentTransactions = RareTypeMetal
				.SelectRareTypeMetalPerUnitValueAssignmentTransactions(allTransactions);
		assertThat(rareMetalPerUnitValueAssignmentTransactions).containsExactly("glob glob Silver is 34 Credits",
				"prok Gold is 57800 Credits");
	}

	@Test
	public void givenInputWithoutCurrencyAssignments_whenSelectingRareTypeMetalsFromTransactions_itShouldOnlyRareTypeMetals() {
		List<String> transactions = Lists.newArrayList("glob glob Silver is 34 Credits", "prok Gold is 57800 Credits",
				"how many Credits is glob prok Iron ?");
		final List<RareTypeMetal> rareMetals = RareTypeMetal.RareTypeMetalsInTransactionLogs(transactions, galacticCurrencies);
		assertThat(rareMetals).extracting("symbol").containsExactly("Silver", "Gold");
		assertThat(rareMetals).extracting("perUnitValue").contains(BigDecimal.valueOf(17), BigDecimal.valueOf(11560));
	}

	@Test
	public void givenAListOfTransaction_whenRareTypeMetalTransactionsAreProcessed_itShouldSelectRareTypeMetalTransactionsAndBuildRareTypeMetalsFromTransactions() {
		List<String> transactions = Lists.newArrayList("glob glob Silver is 34 Credits", "prok Gold is 57800 Credits",
				"how many Credits is glob prok Iron ?");
		final List<RareTypeMetal> rareMetals = RareTypeMetal.RareTypeMetalsInTransactionLogs(transactions, galacticCurrencies);
		assertThat(rareMetals).extracting("symbol").containsExactly("Silver", "Gold");
		assertThat(rareMetals).extracting("perUnitValue").contains(BigDecimal.valueOf(17), BigDecimal.valueOf(11560));

	}
}
