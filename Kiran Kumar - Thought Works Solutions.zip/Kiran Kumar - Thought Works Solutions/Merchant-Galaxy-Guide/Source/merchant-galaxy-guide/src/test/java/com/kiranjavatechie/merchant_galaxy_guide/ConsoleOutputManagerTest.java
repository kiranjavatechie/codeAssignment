package com.kiranjavatechie.merchant_galaxy_guide;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.kiranjavatechie.merchant_galaxy_guide.domain.GalacticCurrency;
import com.kiranjavatechie.merchant_galaxy_guide.domain.GalacticCurrencyExpression;
import com.kiranjavatechie.merchant_galaxy_guide.domain.RareTypeMetal;
import com.kiranjavatechie.merchant_galaxy_guide.domain.RomanTypeSymbols;


public class ConsoleOutputManagerTest {

	 List<GalacticCurrency> galacticCurrencies;

	    @Before
	    public void setup() {
	        RomanTypeSymbols romanSymbolThousand = RomanTypeSymbols.StandaloneSymbol('M', 1000);
	        RomanTypeSymbols romanSymbolFiveHundred = RomanTypeSymbols.StandaloneSymbol('D', 500);
	        RomanTypeSymbols romanSymbolFifty = RomanTypeSymbols.StandaloneSymbol('L', 50);
	        RomanTypeSymbols romanSymbolFive = RomanTypeSymbols.StandaloneSymbol('V', 5);
	        RomanTypeSymbols romanSymbolHundred = RomanTypeSymbols.RepeatableAndSubtractableSymbol('C', Lists.newArrayList(romanSymbolFiveHundred, romanSymbolThousand), 100);
	        RomanTypeSymbols romanSymbolTen = RomanTypeSymbols.RepeatableAndSubtractableSymbol('X', Lists.newArrayList(romanSymbolFifty, romanSymbolHundred), 10);
	        RomanTypeSymbols romanSymbolOne = RomanTypeSymbols.RepeatableAndSubtractableSymbol('I', Lists.newArrayList(romanSymbolFive, romanSymbolTen), 1);
	        galacticCurrencies = ImmutableList.of(new GalacticCurrency("glob", romanSymbolOne), new GalacticCurrency("prok", romanSymbolFive), new GalacticCurrency("pish", romanSymbolTen),
	                new GalacticCurrency("tegj", romanSymbolFifty));

	    }


	    @Test
	    public void givenAllTransactions_whenSelectingGalacticCurrencyTransactions_itShouldReturnAllGalacticCurrencyTransaction() {
	        List<String> allTransactions = Lists.newArrayList("glob is I", "glob glob Silver is 34 Credits", "prok Gold is 57800 Credits", "how much is pish tegj glob glob ?");
	        final List<String> rareMetalPerUnitValueAssignmentTransactions = ConsoleOutputManager.SelectGalacticCurrencyTransactions(allTransactions);
	        assertThat(rareMetalPerUnitValueAssignmentTransactions).containsExactly("how much is pish tegj glob glob ?");
	    }

	    @Test
	    public void givenAllTransactions_whenSelectingCreditsTransactions_itShouldReturnAllCreditsTransactions() {
	        List<String> allTransactions = Lists.newArrayList("glob is I", "glob glob Silver is 34 Credits", "prok Gold is 57800 Credits"
	                , "how much is pish tegj glob glob ?", "how many Credits is glob prok Gold ?", "how many Credits is glob prok Iron ?");
	        final List<String> rareMetalPerUnitValueAssignmentTransactions = ConsoleOutputManager.SelectCreditTransactions(allTransactions);
	        assertThat(rareMetalPerUnitValueAssignmentTransactions).containsExactly("how many Credits is glob prok Gold ?", "how many Credits is glob prok Iron ?");
	    }

	    @Test
	    public void givenACreditsTransaction_whenOutputStringIsCreated_itShouldCreateAOutputStringWithCreditsValue() {
	        String expected = "glob prok Silver is 10 Credits";
	        final String transactionOutputString = ConsoleOutputManager.
	                FormatCreditsTransactionOutputString("how many Credits is glob prok Silver ?", BigDecimal.TEN, galacticCurrencies.subList(0, 2));
	        assertThat(transactionOutputString).isEqualTo(expected);
	    }

	    @Test
	    public void givenAGalacticCurrencyExpressionTransaction_whenOutputStringIsCreated_itShouldCreateAOutputStringWithExpressionValue() {
	        String expected = "pish tegj glob glob is 42";
	        List<GalacticCurrency> galacticCurrenciesInExpression = Lists.newArrayList(galacticCurrencies.get(2), galacticCurrencies.get(3),
	                galacticCurrencies.get(0), galacticCurrencies.get(0));
	        final String transactionOutputString = ConsoleOutputManager.
	                FormatOutputStringForSingleExpressionTransaction("how much is pish tegj glob glob ?", new GalacticCurrencyExpression(galacticCurrenciesInExpression));
	        assertThat(transactionOutputString).isEqualTo(expected);
	    }

	    @Test
	    public void givenListOfCreditsTransactions_whenProcessingCreditsTransactions_itShouldReturnProcessedCreditsOutputTransactions() {
	        List<String> merchantTransactions = Lists.newArrayList("glob is I", "prok is V", "pish is X", "tegj is L", "glob glob Silver is 34 Credits",
	                "glob prok Gold is 57800 Credits", "pish pish Iron is 3910 Credits", "how much is pish tegj glob glob ?",
	                "how many Credits is glob prok Silver ?", "how many Credits is glob prok Gold ?",
	                "how many Credits is glob prok Iron ?");
	        RareTypeMetal gold = new RareTypeMetal("Gold",BigDecimal.valueOf(14450));
	        RareTypeMetal silver = new RareTypeMetal("Silver",BigDecimal.valueOf(17));
	        RareTypeMetal iron= new RareTypeMetal("Iron",BigDecimal.valueOf(195.5));
	        final List<RareTypeMetal> rareMetals = Lists.newArrayList(gold, silver, iron);
	        ConsoleOutputManager consoleOutputManager = new ConsoleOutputManager(galacticCurrencies);
	        final List<String> output = consoleOutputManager.
	                printCreditsTransactionsInTransactionLogs(merchantTransactions, rareMetals);
	        assertThat(output).isEqualTo(Lists.newArrayList("glob prok Silver is 68 Credits","glob prok Gold is 57800 Credits","glob prok Iron is 782 Credits"));
	    }

	    @Test
	    public void givenListOfGalacticCurrencyExpressionTransactions_whenGalacticCurrencyExpressioniTransactions_itShouldReturnProcessedGalacticCurrencyOutputTransactions() {
	        List<String> merchantTransactions = Lists.newArrayList("glob is I", "prok is V", "pish is X", "tegj is L", "glob glob Silver is 34 Credits",
	                "glob prok Gold is 57800 Credits", "pish pish Iron is 3910 Credits", "how much is pish tegj glob glob ?",
	                "how many Credits is glob prok Silver ?", "how many Credits is glob prok Gold ?",
	                "how many Credits is glob prok Iron ?");
	        ConsoleOutputManager consoleOutputManager = new ConsoleOutputManager(galacticCurrencies);
	        final List<String> output = consoleOutputManager.printGalacticCurrencyExpressionInTransactionLogs(merchantTransactions);
	        assertThat(output).isEqualTo(Lists.newArrayList("pish tegj glob glob is 42"));
	    }

}
