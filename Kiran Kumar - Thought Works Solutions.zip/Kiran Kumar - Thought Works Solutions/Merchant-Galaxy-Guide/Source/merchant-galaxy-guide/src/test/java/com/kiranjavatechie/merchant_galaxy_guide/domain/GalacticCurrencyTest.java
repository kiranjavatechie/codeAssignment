package com.kiranjavatechie.merchant_galaxy_guide.domain;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;



public class GalacticCurrencyTest {

	 List<GalacticCurrency> galacticCurrencies;

	    @Before
	    public void setup(){
	        RomanTypeSymbols romanSymbolThousand = RomanTypeSymbols.StandaloneSymbol('M',1000);
	        RomanTypeSymbols romanSymbolFiveHundred = RomanTypeSymbols.StandaloneSymbol('D',500);
	        RomanTypeSymbols romanSymbolFifty = RomanTypeSymbols.StandaloneSymbol('L',50);
	        RomanTypeSymbols romanSymbolFive = RomanTypeSymbols.StandaloneSymbol('V',5);
	        RomanTypeSymbols romanSymbolHundred = RomanTypeSymbols.RepeatableAndSubtractableSymbol('C',Lists.newArrayList(romanSymbolFiveHundred,romanSymbolThousand),100);
	        RomanTypeSymbols romanSymbolTen = RomanTypeSymbols.RepeatableAndSubtractableSymbol('X',Lists.newArrayList(romanSymbolFifty,romanSymbolHundred),10);
	        RomanTypeSymbols romanSymbolOne = RomanTypeSymbols.RepeatableAndSubtractableSymbol('I',Lists.newArrayList(romanSymbolFive,romanSymbolTen),1);
	        galacticCurrencies = ImmutableList.of(new GalacticCurrency("glob",romanSymbolOne), new GalacticCurrency("prok",romanSymbolFive), new GalacticCurrency("pish",romanSymbolTen),
	                new GalacticCurrency("tegj",romanSymbolFifty));

	    }

	    @Test
	    public void givenRareMetalAssignmentTransaction_whenCreatingGalacticCurrencies_itShouldCreateGalacticCurrenciesFromTheCurrenciesInTheTransaction() throws Exception {
	        List<GalacticCurrency> galacticCurrenciesFromTransaction =
	                GalacticCurrency.createFromTransactionComponents(Lists.newArrayList("glob","glob","Silver","is","34","Credits"), this.galacticCurrencies);
	        assertThat(galacticCurrenciesFromTransaction).extracting("symbol").containsExactly("glob","glob");

	        galacticCurrenciesFromTransaction =
	                GalacticCurrency.createFromTransactionComponents(Lists.newArrayList("glob","prok","Gold","is","57800","Credits"), this.galacticCurrencies);
	        assertThat(galacticCurrenciesFromTransaction).extracting("symbol").containsExactly("glob","prok");

	        galacticCurrenciesFromTransaction =
	                GalacticCurrency.createFromTransactionComponents(Lists.newArrayList("pish","Iron","is","3910","Credits"), this.galacticCurrencies);
	        assertThat(galacticCurrenciesFromTransaction).extracting("symbol").containsExactly("pish");

	    }

	    @Test
	    public void givenGalacticCurrencyTransaction_whenCreatingGalacticCurrencies_itShouldCreateGalacticCurrenciesFromTheCurrenciesInTheTransaction() throws Exception {
	        List<GalacticCurrency> galacticCurrenciesFromTransaction =
	                GalacticCurrency.createFromTransactionComponents(Lists.newArrayList("how","much","is","pish","tegj","glob","?"), this.galacticCurrencies);
	        assertThat(galacticCurrenciesFromTransaction).extracting("symbol").containsExactly("pish","tegj","glob");
	    }

	    @Test
	    public void givenCreditCalculationTransaction_whenCreatingGalacticCurrencies_itShouldCreateGalacticCurrenciesFromTheCurrenciesInTheTransaction() throws Exception {
	        List<GalacticCurrency> galacticCurrenciesFromTransaction =
	                GalacticCurrency.createFromTransactionComponents(Lists.newArrayList("how","many","Credits","is","glob","prok","Silver","?"), this.galacticCurrencies);
	        assertThat(galacticCurrenciesFromTransaction).extracting("symbol").containsExactly("glob","prok");
	    }

	    public void givenTransactionWithZeroGalacticCurrencies_whenCreatingGalacticCurrencies_itShouldThrowInvalidTransactionException() throws Exception {
	        List<GalacticCurrency> galacticCurrenciesFromTransaction =
	                GalacticCurrency.createFromTransactionComponents(Lists.newArrayList("how","many","Credits","is","Silver","?"), this.galacticCurrencies);
	        assertThat(galacticCurrenciesFromTransaction).isEmpty();
	    }
}
