package com.kiranjavatechie.conference_track_management.exceptions;

/**
 * 
 * @author Kiran Kumar
 *
 */
public class UnsupportedDestinationException extends Throwable {

    public UnsupportedDestinationException(String message) {
        super(message);
    }

}
