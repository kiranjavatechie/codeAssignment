package com.kiranjavatechie.conference_track_management.enums;

/**
 * 
 * @author Kiran Kumar
 *
 */
public enum  DataSourceEnum {

    FILE;
}
