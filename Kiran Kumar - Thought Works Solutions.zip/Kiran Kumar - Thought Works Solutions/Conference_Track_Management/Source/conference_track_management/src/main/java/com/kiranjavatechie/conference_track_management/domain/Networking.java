package com.kiranjavatechie.conference_track_management.domain;

import java.text.SimpleDateFormat;

import com.kiranjavatechie.conference_track_management.ConferenceManagementConfig;

/**
 * @author Kiran Kumar
 */
public class Networking extends Event {

    public Networking () {
        super(ConferenceManagementConfig.NETWORKING_START_TIME, "Networking Event", 0);
    }
}
