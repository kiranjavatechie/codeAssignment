package com.kiranjavatechie.conference_track_management;

import java.util.List;

import com.kiranjavatechie.conference_track_management.domain.Conference;
import com.kiranjavatechie.conference_track_management.domain.Talk;
import com.kiranjavatechie.conference_track_management.enums.DataOutputEnum;
import com.kiranjavatechie.conference_track_management.enums.DataSourceEnum;
import com.kiranjavatechie.conference_track_management.exceptions.UnsupportedDestinationException;
import com.kiranjavatechie.conference_track_management.exceptions.UnsupportedSourceException;
import com.kiranjavatechie.conference_track_management.util.ConferenceUtils;

/**
 * 
 * @author Kiran Kumar
 *
 */
public class ConferenceTrackMgmtApp 
{
    public static void main( String[] args )
    {
       
        ConferenceManager conferenceManager = new ConferenceManager();
        List<Talk> talkList = null;
        // Fetch the input talk list.
        try {
            talkList = conferenceManager.fetchTalksListFromSource(DataSourceEnum.FILE);
        } catch (UnsupportedSourceException e){
            System.err.println(e.getMessage());
        }

        if(talkList == null || talkList.size() == 0)
            return;

        // Print talks.
        ConferenceUtils.printTalks(talkList);

        // Process and schedule talks into events and slots.
        Conference conference = conferenceManager.processAndScheduleTalks(talkList);

        // Output the conference events.
        try {
            conferenceManager.outputConferenceSchedule(conference, DataOutputEnum.CONSOLE);
        } catch (UnsupportedDestinationException e){
            System.err.println(e.getMessage());
        }

    }
}
