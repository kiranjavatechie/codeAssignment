package com.kiranjavatechie.conference_track_management.enums;

/**
 * 
 * @author Kiran Kumar
 *
 */
public enum DataOutputEnum {
    CONSOLE;
}
