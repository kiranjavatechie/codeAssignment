package com.kiranjavatechie.conference_track_management.domain;

import java.text.SimpleDateFormat;

import com.kiranjavatechie.conference_track_management.ConferenceManagementConfig;

/**
 * 
 * @author Kiran Kumar
 *
 */
public class Lunch extends Event {
    public Lunch() {
        super(ConferenceManagementConfig.LUNCH_START_TIME, "Lunch", ConferenceManagementConfig.LUNCH_DURATION_MINUTES);
    }
}
