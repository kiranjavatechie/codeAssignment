package com.kiranjavatechie.conference_track_management.exceptions;

/**
 * 
 * @author Kiran Kumar
 *
 */
public class UnsupportedSourceException extends Throwable {

    public UnsupportedSourceException(String message) {
        super(message);
    }
}
